Para compilar el archivo thread.c utilizar el comando
gcc -pthread -o thread.o thread.c

Luego correr 
./thread.o
